# McOS-XFCE-Edition
Mac OS-themes for the XFCE desktop
