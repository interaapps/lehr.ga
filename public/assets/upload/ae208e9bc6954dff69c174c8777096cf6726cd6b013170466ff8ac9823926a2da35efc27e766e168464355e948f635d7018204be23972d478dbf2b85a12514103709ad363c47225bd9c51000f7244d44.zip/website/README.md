# Meine Internetseite
Der Code von meiner Internetseite
# 
In den .html Datein steht der ganze Quellcode für die Internetseiten.
In den .css Datein steht der ganze "Design-Code" für die Internetseiten. (Im Ordner sylesheets)

Ihr könnt dieses Projekt ruhig als stütze für euer eigenes HTML Projekt
verwenden. Wenn ihr fragen habt, stellt sie mir einfach!

contact@nivram710.de

Viel Spaß mit dem Projekt!

## Status
Aufgrund der DSGVO offline. Wenn ihr euch die Website anschauen wollt, dann ladet sie herunter und öffnet
die index.html Datei.

# Nivram710
